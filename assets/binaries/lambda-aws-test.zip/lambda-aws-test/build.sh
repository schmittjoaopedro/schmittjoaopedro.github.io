# Install dependencies
python3 -m pip install -r requirements.txt
sudo apt install -y zip

# Run tests
python3 -m unittest discover -v 

# Clean-up
rm -rf bin
find . -name __pycache__ -exec rm -rf {} \;

# Build ZIP to upload into Lambda
mkdir bin
(cd src && zip -r - .) > bin/source.zip