import os
import sys
import unittest
import json
from unittest.mock import patch
from unittest.mock import MagicMock

# To resolve handler import for modules from its relative path
TEST_DIR = os.path.dirname(os.path.abspath(__file__))
HANDLER_ROOT_DIR = os.path.join(TEST_DIR, '..', 'src')
sys.path.insert(0, HANDLER_ROOT_DIR)

@patch('boto3.client')
class LambdaHandlerTest(unittest.TestCase):

    sqs_url = "https://sqs.us-east-1.amazonaws.com/12345678910/my-simple-queue"

    def setUp(self):
        os.environ["QUEUE_URL"] = self.sqs_url

    def tearDown(self):
        # Delete the module under test to reload it and get fresh mocked contexts
        del sys.modules['src.lambda_handler']
    
    def test_empty_records(self, botoClientMock):
        # Given there are no records on the event
        event = { "Records": [] }

        # When calling the lambda handler
        from src.lambda_handler import handler
        handler(event, None)

        # Then no S3 file is fetched
        self.assertEqual(0, len(botoClientMock("s3").get_object.mock_calls))

    def test_simple_file_is_parsed(self, botoClientMock):
        # Given there is a single record to be processed
        file = open(f"{TEST_DIR}/fixtures/sample.csv", 'rb')
        botoClientMock("s3").get_object.side_effect = \
            (lambda Bucket, Key: { "Body": file } if Bucket == 'my-simple-bucket' and Key == 'sample.csv' else None)

        # When calling the lambda handler
        printPatch = patch("builtins.print", new=MagicMock())
        printPatch.start()
        from src.lambda_handler import handler
        handler({
            "Records": [{
                "body": """{
                    "Records": [{ 
                        "s3": { 
                            "bucket": { "name": "my-simple-bucket" },
                            "object": { "key": "sample.csv" }
                        }
                    }]
                }"""
            }]
        }, None)
        printPatch.stop()

        # Then the S3 file is downloaded
        self.assertEqual(1, len(botoClientMock().get_object.mock_calls))
        # And the parsed message is sent to the SQS
        message_body = botoClientMock().send_message.mock_calls[0][2]
        self.assertEqual(self.sqs_url, message_body['QueueUrl'])
        # And the first object is correct
        payload = json.loads(message_body['MessageBody'])
        self.assertEqual('John Doe', payload[0]['name'])
        self.assertEqual('New York', payload[0]['city'])
        self.assertEqual('USA', payload[0]['country'])
        # And the last object is correct
        self.assertEqual('Baz Smith', payload[len(payload) - 1]['name'])
        self.assertEqual('Porto', payload[len(payload) - 1]['city'])
        self.assertEqual('Portugal', payload[len(payload) - 1]['country'])

