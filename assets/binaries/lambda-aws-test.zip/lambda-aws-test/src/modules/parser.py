
class Parser:
    
    def parse(self, fileContent):
        contentRows = fileContent.splitlines()
        headers = contentRows[0].split(',')
        data = []
        for idx_row in range(1, len(contentRows)):
            row = contentRows[idx_row].split(',')
            obj = {}
            for idx_col in range(0, len(headers)):
                obj[headers[idx_col]] = row[idx_col]
            data.append(obj)
        return data