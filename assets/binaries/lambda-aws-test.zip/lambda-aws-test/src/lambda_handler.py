import boto3
import os
import urllib.parse
import json

from modules.parser import Parser

QUEUE_URL = os.environ.get('QUEUE_URL')

S3 = boto3.client('s3')
SQS = boto3.client('sqs')
parser = Parser()

def handler(event, context):
 
    for eventRecord in event["Records"]:
        body = json.loads(eventRecord["body"])

        for s3Record in body["Records"]:
            # Obtain S3 file
            bucket = s3Record["s3"]["bucket"]["name"]
            key = urllib.parse.unquote_plus(s3Record["s3"]["object"]["key"], encoding="utf-8")
            csv_file = get_csv_file(bucket, key)

            # Parse and send to SQS
            parsed_data = parser.parse(csv_file)            
            SQS.send_message(QueueUrl = QUEUE_URL, MessageBody = json.dumps(parsed_data, separators=(',', ':')))

def get_csv_file(bucket, key):
    try:
        return S3.get_object(Bucket=bucket, Key=key)["Body"].read().decode("utf-8") 
    except Exception as e:
        print(f"Error fetching s3://{bucket}/{key}. {e}.")
        raise e